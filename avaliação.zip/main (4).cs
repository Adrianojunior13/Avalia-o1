using System;

class Program
{
    static void Main()
    {
        // Lê a idade em dias
        Console.Write("Digite a idade em dias: ");
        int dias = int.Parse(Console.ReadLine());

        // Calcula o n
        int anos = dias / 365;
        dias = dias % 365;
        
        int meses = dias / 30;
        dias = dias % 30;

        // Exibe a idade em anos, meses e dias
        Console.WriteLine($"{anos} anos, {meses} meses, {dias} dias.");
    }
}